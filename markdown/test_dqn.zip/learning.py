import gym
import copy
import chainer
import chainer.functions as F
import chainer.links as L
from chainer import training
from chainer.training import extensions
from collections import deque
from chainer import optimizers, Variable, serializers
import numpy as np


class Neuralnet(chainer.Chain):
    # ニューラルネットワーク生成(chainerで実装)
    def __init__(self, n_in, n_out):
        super(Neuralnet, self).__init__(
            L1 = L.Linear(n_in, 100),
            L2 = L.Linear(100, 100),
            L3 = L.Linear(100, 100),
            # Q値を初期化する(※n_outは指定できるアクションの数)
            Q_value = L.Linear(100, n_out, initialW=np.zeros((n_out, 100), dtype=np.float32))
        )

    # 活性化
    def Q_func(self, x):
        h = F.leaky_relu(self.L1(x))
        h = F.leaky_relu(self.L2(h))
        h = F.leaky_relu(self.L3(h))
        h = self.Q_value(h)
        return h


class Agent():
    def __init__(self, n_st, n_act):
        self.n_act = n_act
        self.model = Neuralnet(n_st, n_act)
        self.target_model = copy.deepcopy(self.model)
        self.optimizer = optimizers.Adam()
        self.optimizer.setup(self.model)
        self.memory = deque()
        self.loss = 0
        self.step = 0
        self.gamma = 0.99            # 割引率
        self.mem_size = 1000         # Experience Replayのために覚えておく経験の数
        self.batch_size = 100        # Experience Replayの際のミニバッチの大きさ
        self.train_freq = 10         # ニューラルネットワークの学習間隔
        self.target_update_freq = 20 # ターゲットネットワークの同期間隔
        # ε-greedy paramters
        self.epsilon = 1             # εの初期値
        self.epsilon_decay = 0.005   # εの減衰値
        self.epsilon_min = 0         # εの最小値
        self.exploration = 1000      # εを減衰し始めるまでのステップ数(今回はメモリーが貯まるまで)


    # Q値の学習用に状態をFIFOしておく
    def stock_experience(self, st, act, r, st_dash, ep_end):
        self.memory.append((st, act, r, st_dash, ep_end))
        if len(self.memory) > self.mem_size:
            self.memory.popleft()

    # データのシャッフル
    def suffle_memory(self):
        mem = np.array(self.memory)
        return np.random.permutation(mem)

    # ミニバッチの取得
    def parse_batch(self, batch):
        st, act, r, st_dash, ep_end = [], [], [], [], []
        for i in range(self.batch_size):
            st.append(batch[i][0])
            act.append(batch[i][1])
            r.append(batch[i][2])
            st_dash.append(batch[i][3])
            ep_end.append(batch[i][4])
        st = np.array(st, dtype=np.float32)
        act = np.array(act, dtype=np.int8)
        r = np.array(r, dtype=np.float32)
        st_dash = np.array(st_dash, dtype=np.float32)
        ep_end = np.array(ep_end, dtype=np.bool)
        return st, act, r, st_dash, ep_end

    # Q値の更新
    def experience_replay(self):
        # 格納していたデータ(状態, アクション, 報酬, 次の状態,
        # エピソード終了の有無)をシャッフル
        mem = self.suffle_memory()
        perm = np.array(range(len(mem)))
        for start in perm[::self.batch_size]:
            index = perm[start:start+self.batch_size]
            batch = mem[index]
            # ミニバッチで切り出し
            st, act, r, st_d, ep_end = self.parse_batch(batch)
            # 最適化処理
            self.model.zerograds()
            loss = self.forward(st, act, r, st_d, ep_end)
            loss.backward()
            self.optimizer.update()

    # 順方向伝播(chainerで実装)
    def forward(self, st, act, r, st_dash, ep_end):
        s = Variable(st)
        s_dash = Variable(st_dash)
        Q = self.model.Q_func(s)
        tmp = self.target_model.Q_func(s_dash)
        tmp = list(map(np.max, tmp.data))
        max_Q_dash = np.asanyarray(tmp, dtype=np.float32)
        target = np.asanyarray(copy.deepcopy(Q.data), dtype=np.float32)
        for i in range(self.batch_size):
            target[i, act[i]] = r[i] + (self.gamma * max_Q_dash[i]) * (not ep_end[i])
        loss = F.mean_squared_error(Q, Variable(target))
        return loss

    # 次のアクションの取得
    def get_action(self, st):
        # 乱数がεより低い場合は次の状態をランダムに選択
        # (この処理がない場合初期のQ値で選択するアクションが固定される)
        if np.random.rand() < self.epsilon:
            return np.random.randint(0, self.n_act)
        # 上記でない場合、Q値がもっとも高いアクションを選択
        else:
            s = Variable(st)
            Q = self.model.Q_func(s)
            Q = Q.data[0]
            a = np.argmax(Q)
            return np.asarray(a, dtype=np.int8)

    # εを減少させる
    def reduce_epsilon(self):
        if self.epsilon > self.epsilon_min and self.exploration < self.step:
            self.epsilon -= self.epsilon_decay

    # Q値の学習
    def train(self):
        if len(self.memory) >= self.mem_size:
            if self.step % self.train_freq == 0:
                # Q値の更新
                self.experience_replay()
                # 学習が進むにつれεを減少させる(よりゴールに近いアクションを選択させるため)
                self.reduce_epsilon()
            if self.step % self.target_update_freq == 0:
                self.target_model = copy.deepcopy(self.model)
        self.step += 1

def main(env_name):
    # env         : ゲーム自体の環境
    # observation : 観測値(車の位置, 速度) main関数の表参照
    # episode     : ゲームの実行回数
    # agent       : Agentクラスの継承クラス, action()をoverrideすることで
    #          学習後の動作を実現する
    env = gym.make(env_name)

    # ゲームによってアクションが異なるので、ゲームに対応した
    # アクションの配列を生成
    n_st = env.observation_space.shape[0]
    if type(env.action_space) == gym.spaces.discrete.Discrete:
        # CartPole-v0, Acrobot-v0, MountainCar-v0
        n_act = env.action_space.n
        action_list = range(0, n_act)
    elif type(env.action_space) == gym.spaces.box.Box:
        # Pendulum-v0
        action_list = [np.array([a]) for a in [-2.0, 2.0]]
        n_act = len(action_list)

    # エージェントの生成
    agent = Agent(n_st, n_act)

    # 1000回 エピソード(ゲーム)を実行
    for i_episode in range(1000):
        observation = env.reset()
        for t in range(200):
            # 実行結果(アニメーション)の再生
            env.render()
            state = observation.astype(np.float32).reshape((1,n_st))
            # 次のアクションの取得
            act_i = agent.get_action(state)
            action = action_list[act_i]
            # アクションを実行した場合(車を動かした)の各種パラメータを取得
            observation, reward, ep_end, _ = env.step(action)
            state_dash = observation.astype(np.float32).reshape((1,n_st))
            # 学習用に現在の状態, アクション, 報酬, 次の状態, エピソードの終了
            # をFIFOする
            agent.stock_experience(state, act_i, reward, state_dash, ep_end)
            # 学習
            agent.train()
            # 学習後の車の位置が特定の場合 or 山を登りきった場合
            # 1ゲーム終了
            if ep_end:
                break


if __name__ == "__main__":
    # MountainCar observation are following paramters
    # +-----+--------------+-------+------+
    # | Num | Observation  | Min   | Max  |
    # +=====+==============+=======+======+
    # | 0   | Car Position | -1.2  | 0.6  |
    # | 1   | Car Velocity | -0.07 | 0.07 |
    # +-----+--------------+-------+------+

    # Action are following paramters
    # +-----+----------------------------------------------------------------------+
    # | Num | Action                                                               |
    # +=====+======================================================================+
    # | 0   | Push car to the left(vagative value) or to the right(positive value) |
    # +-----+----------------------------------------------------------------------+

    # Reward is 100 for reaching the target of the hill on the right hand side

    # Starting State: Position between -0.6 and -0.4, null velocity.

    # Episode Termination: Position equal to 0.5
    main("MountainCar-v0")
